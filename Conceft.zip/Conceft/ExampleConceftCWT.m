clear ; %close all ;

addpath('./tool/export_fig') ;
addpath('./Morse') ;
addpath('./tool') ;


%% fix the seed
initstate(23400) ;
opts.motherwavelet = 'morse-b' ;
opts.beta = 20;
opts.gam = 8;
opts.dim = 8 ;
opts.k = 1 ;
MT = 30;

%% high sampling rate to avoid sampling issue
Hz = 50 ;
L = 20 ;
time = [1/Hz:1/Hz:L]' ;
N = length(time) ;
alpha = 0.05 ; 

scrsz = get(0,'ScreenSize');


%% the amplitude modulation of the simulated signal
am1 = smooth(cumsum(randn(N,1)) ./ Hz, 200, 'loess') ;
am1 = 2 + am1 ./ max(abs(am1)) ;
am2 = smooth(cumsum(randn(N,1)) ./ Hz, 200, 'loess') ;
am2 = 2 + am2 ./ max(abs(am2)) ;
am1(1:200) = 0 ;
am2(end-230:end) = 0 ;

%% the instantaneous frequency of the simulated signal
if1 = smooth(cumsum(randn(N,1)) ./ Hz, 400, 'loess') ;
if1 = 5 + if1 ./ max(abs(if1)) ;
if2 = smooth(cumsum(randn(N,1)) ./ Hz, 300, 'loess') ;
if2 = pi + if2 ./ max(abs(if2)) ;
phi1 = cumsum(if1) / Hz ;
phi2 = cumsum(if2) / Hz ;

%% the simulated signal.
clean = am2 .* cos(2*pi*(phi2)) + am1 .* cos(2*pi*phi1) ; %+ 2*cos(2*pi*(time+0.4*time.^2));
if2 = if2 ;% - 0.2*time ;
if1(1:200) = nan ;
if2(end-230:end) = nan ;
if3 = 1+0.8*time ;

%% add noise (Gaussian white noise)
noise = 2 * randn(N, 1) ;
noise(1:end/2) = 1*randn(N/2,1) ;
xm = clean ; % + noise ;


%==================

[tfrsq, tfrsqtic, tfrsqALL, tfrsqOrig, tfrsqALLOrig] = ConceftCWT(time, xm, MT, alpha, 0, 10, opts) 




%%
figure
nrow = 3;
ncol = 4;



subplot(nrow,ncol,1),
imageSQ(time, tfrsqtic, log(1+abs(tfrsqALL(:,:,1)).^2), 'SQ'); 
xlabel('Time (sec)') ; ylabel('Freq') ; title('random vec') ;

subplot(nrow,ncol,2),
imageSQ(time, tfrsqtic, log(1+abs(tfrsqALL(:,:,2)).^2), 'SQ');
xlabel('Time (sec)') ; ylabel('Freq') ; title('random vec') ;

subplot(nrow,ncol,3),
imageSQ(time, tfrsqtic, log(1+abs(tfrsqALL(:,:,3)).^2), 'SQ');
xlabel('Time (sec)') ; ylabel('Freq') ; title('random vec') ;

subplot(nrow,ncol,4),
imageSQ(time, tfrsqtic, log(1+abs(tfrsqALL(:,:,4)).^2), 'SQ');
xlabel('Time (sec)') ; ylabel('Freq') ; title('random vec') ;

subplot(nrow,ncol,5),
imageSQ(time, tfrsqtic, log(1+abs(tfrsqALLOrig(:,:,1)).^2), 'SQ'); 
xlabel('Time (sec)') ; ylabel('Freq') ; title('Morse k=0') ;

subplot(nrow,ncol,6),
imageSQ(time, tfrsqtic, log(1+abs(tfrsqALLOrig(:,:,2)).^2), 'SQ'); 
xlabel('Time (sec)') ; ylabel('Freq') ; title('Morse k=1') ;

subplot(nrow,ncol,7),
imageSQ(time, tfrsqtic, log(1+abs(tfrsqALLOrig(:,:,4)).^2), 'SQ');
xlabel('Time (sec)') ; ylabel('Freq') ; title('Morse k=3') ;

subplot(nrow,ncol,8),
imageSQ(time, tfrsqtic, log(1+abs(tfrsqOrig).^2), 'SQ');
xlabel('Time (sec)') ; ylabel('Freq') ; title(['MT k=0-',num2str(opts.dim)]) ;



subplot(nrow,ncol,11)
imageSQ(time, tfrsqtic, log(1+abs(tfrsq).^2), 'SQ'); title(['new MT (',num2str(MT),')']);
colorbar

subplot(nrow,ncol,12)
imageSQ(time, tfrsqtic, log(1+abs(tfrsq).^2), 'SQ'); title(['new MT (',num2str(MT),')']);
hold on ; plot(time, if1/alpha,'r--','linewidth',2) ; plot(time, if2/alpha, 'r--','linewidth',2) ; %plot(time, if3/alpha,'r--','linewidth',2) ;
