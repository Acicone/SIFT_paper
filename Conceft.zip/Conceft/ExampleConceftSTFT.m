clear ; close all ;

addpath('./tool/export_fig') ;
addpath('./Morse') ;
addpath('./tool') ;

scrsz = get(groot,'ScreenSize');

	%% generate the simulated data
	%% she sampling time (100Hz sampling rate)
	%% high sampling rate to avoid sampling issue
Hz = 100 ;
L = 12 ;
N = Hz * L ;


	%% options for Conceft
opts.WinLen = 301 ;
opts.dim = 4 ;
        %% FreqRes is the resolution in the frequency axis
opts.NonHermitWindow = 0 ;

        %% Setup parameters
        %% the number of random Multitaper (rMT)
MT = 10 ;
        %% alpha is the grid size in the freq axis
alpha = 0.01/Hz ;
SigmaNo = [1] ;% 2 3] ;



for pp = 1:length(SigmaNo)	%% different noise levels
for rr = 1: 1 		%% different realizations

initstate(rr) ;
qq = 1; 
sigma = SigmaNo(pp) ;


	%% the amplitude modulation of the simulated signal
am1 = smooth(cumsum(randn(N,1)) ./ Hz, 200, 'loess') ;
am1 = 2 + am1 ./ max(abs(am1)) ;
am2 = smooth(cumsum(randn(N,1)) ./ Hz, 200, 'loess') ;
am2 = 2 + am2 ./ max(abs(am2)) ;
am1(1:300) = 0 ;
am2(end-400:end) = 0 ;


    %% the instantaneous frequency of the simulated signal
if1 = smooth(cumsum(randn(N,1)) ./ Hz, 400, 'loess') ;
if1 = 10 + 6 * if1 ./ max(abs(if1)) ;
if2 = smooth(cumsum(randn(N,1)) ./ Hz, 300, 'loess') ;
if2 = pi + 3 * if2 ./ max(abs(if2)) ;
phi1 = cumsum(if1) / Hz ; 
phi2 = cumsum(if2) / Hz ; 
if1(1:300) = nan ;
if2(end-400:end) = nan ;

	%% the simulated signal.
clean = am1 .* cos(2*pi*phi1) + am2 .* cos(2*pi*phi2) ; 
	%% add noise (Gaussian white noise)

noise = sigma * randn(N, 1) ; 
%dis = random('t',4,N, 1) ;
%e = armaxfilter_simulate(dis, .5, 1, .5, 1, -.5) ;
%noise = sigma * e ./ std(e) ;
snrdb = 20 * log10(std(clean)./std(noise)) ;
fprintf(['snrdb = ',num2str(snrdb),'\n']) ;


	%% simulated observed time series
xm = clean + noise ;


time = [1/Hz:1/Hz:L]' ;


%%%% Conceft %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[h,Dh,t] = hermf(opts.WinLen, 1, 6) ;
[tfr, tfrtic, tfrsqClean, tfrsqtic] = sqSTFT(xm, 0/Hz, 10/Hz, 0.5/length(xm), 1, h', Dh') ; 

[tfrsq, tfrsqtic, tfrsqALL, tfrsqOrig, tfrsqALLOrig] = ConceftSTFT(time, xm, MT, alpha, 0/Hz, 10/Hz, opts) ;


mat = 17 + 3*(xm - min(xm)) ./ (max(xm) - min(xm)) ;
clean = 17 + 3*(clean - min(clean)) ./ (max(clean) - min(clean)) ;

	%% plot the result for comparison
figure('Position',[1 scrsz(4)/2 scrsz(3) scrsz(4)])

subplot(3, 4, 1) ;
imageRTF(time, tfrsqtic*Hz, log(1+abs(tfrsqClean).^2)) ; colormap(1-gray) ;
set(gca,'fontsize', 20) ; axis([0 inf 0 20]) ;
hold on ; plot(time, clean) ;
xlabel('Time (sec)') ; ylabel('Freq') ;
title('sqSTFT clean') ;

subplot(3, 4, 3) ;
imageRTF(time, tfrsqtic*Hz, log(1+abs(tfrsqALL(:, :, 1)).^2)) ; colormap(1-gray) ;
set(gca,'fontsize', 20) ;
axis([0 inf 0 20]) ;
xlabel('Time (sec)') ; ylabel('Freq') ;
title('sqSTFT rv1') ;
	
subplot(3, 4, 4) ;
imageRTF(time, tfrsqtic*Hz, log(1+abs(tfrsqALL(:, :, 2)).^2)) ; colormap(1-gray) ;
set(gca,'fontsize', 20) ;
axis([0 inf 0 20]) ;
xlabel('Time (sec)') ; ylabel('Freq') ;
title('sqSTFT rv2') ;

subplot(3, 4, 5) ;
imageRTF(time, tfrsqtic*Hz, log(1+abs(tfrsqALL(:, :, 3)).^2)) ; colormap(1-gray) ;
set(gca,'fontsize', 20) ;
axis([0 inf 0 20]) ;
xlabel('Time (sec)') ; ylabel('Freq') ;
title('sqSTFT rv3') ;


subplot(3, 4, 6) ;
imageRTF(time, tfrsqtic*Hz, log(1+abs(tfrsqALLOrig(:,:,2)).^2)) ; colormap(1-gray) ;
set(gca,'fontsize', 20) ;
axis([0 inf 0 20]) ;
xlabel('Time (sec)') ; ylabel('Freq') ;
title('sqSTFT H1') ;


subplot(3, 4, 7) ;
imageRTF(time, tfrsqtic*Hz, log(1+abs(tfrsqOrig).^2)) ; colormap(1-gray) ;
set(gca,'fontsize', 20) ;
axis([0 inf 0 20]) ;
xlabel('Time (sec)') ; ylabel('Freq') ;
title('MT sqSTFT (H0-H5)') ;


subplot(3, 4, 11) ;
imageRTF(time, tfrsqtic*Hz, log(1+abs(tfrsq).^2)) ; colormap(1-gray) ;
set(gca,'fontsize', 20) ;
axis([0 inf 0 20]) ;
xlabel('Time (sec)') ; ylabel('Freq') ;  colorbar
title([num2str(MT),'ConceftSTFT']) ;

subplot(3, 4, 12) ;
imageRTF(time, tfrsqtic*Hz, log(1+abs(tfrsq).^2)) ; colormap(1-gray) ;
set(gca,'fontsize', 20) ;
axis([0 inf 0 20]) ;
xlabel('Time (sec)') ; ylabel('Freq') ;
hold on; colorbar
plot(time, if1, 'r','linewidth',2) ; plot(time, if2, 'b','linewidth',2) ;
title([num2str(MT),'ConceftSTFT']) ;

fprintf('\n') ;


end
end
